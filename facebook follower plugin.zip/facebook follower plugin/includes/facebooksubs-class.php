<?php
/**
 * Adds Facebook_Subs widget.
 */

add_action('widgets_init', create_function('', 'return register_widget("Facebook_Subs_Widget");'));
class Facebook_Subs_Widget extends WP_Widget {

    /**
     * Register widget with WordPress.
     */
    function __construct() {
        parent::__construct(
            'Facebook_Subs_Widget',
            __( 'Facebook Follow Button', 'facebook_Subs_Widget-new' ),
            array( 'description' => __( 'Add the Follow Button to your blog to increase engagement and create a lasting connection with your audience.', 'facebook_Subs_Widget-new'), )
        );
    }


    public function form( $instance ) {
        if ( $instance ) {
            $fsw_title = esc_attr($instance['fsw_title']);
            $fsw_username = esc_attr($instance['fsw_username']);
            $fsw_data_show_count = esc_attr($instance['fsw_data_show_count']);
            $fsw_size = esc_attr($instance['fsw_size']);
            $fsw_show_screen_name = esc_attr($instance['fsw_show_screen_name']);
            $fsw_data_dnt = esc_attr($instance['fsw_data_dnt']);
            $fsw_language = esc_attr($instance['fsw_language']);
        }
        else {
            $fsw_title = __( 'Follow Button', 'facebook_Subs_Widget-new' );
            $fsw_username = 'gem6_15@yahoo.co.in';
            $fsw_data_show_count = 'true';
            $fsw_size = 'medium';
            $fsw_show_screen_name = 'true';
            $fsw_data_dnt = 'false';
            $fsw_language = 'en';
        }
        ?>



        <!-- TITLE -->
        <p>
            <label for="<?php echo $this->get_field_id('fsw_title'); ?>">
                <?php _e('Title:', 'facebook_Subs_Widget-new'); ?>
            </label>
            <input class="widefat" id="<?php echo $this->get_field_id('fsw_title'); ?>" name="<?php echo $this->get_field_name('fsw_title'); ?>" type="text" value="<?php echo $fsw_title; ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('fsw_username'); ?>">
                <?php _e('Facebook Username:', 'facebook_Subs_Widget-new'); ?>
            </label>
            <input class="widefat" id="<?php echo $this->get_field_id('fsw_username'); ?>" name="<?php echo $this->get_field_name('fsw_username'); ?>" type="text" value="<?php echo $fsw_username; ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('fsw_data_show_count'); ?>">
                <?php _e('Followers count:', 'facebook_Subs_Widget-new'); ?>

            </label>
            <select id="<?php echo $this->get_field_id('fsw_data_show_count'); ?>" name="<?php echo $this->get_field_name('fsw_data_show_count'); ?>">
                <option value="true" <?php selected( 'true', $fsw_data_show_count ); ?>><?php _e('Yes', 'facebook_Subs_Widget-new'); ?></option>
                <option value="false" <?php selected( 'false', $fsw_data_show_count ); ?>><?php _e('No', 'facebook_Subs_Widget-new'); ?></option>
            </select>

        </p>
        <p>
            <label for="<?php echo $this->get_field_id('fsw_size'); ?>">
                <?php _e('Button Size:', 'facebook_Subs_Widget-new'); ?>

            </label>
            <select id="<?php echo $this->get_field_id('fsw_size'); ?>" name="<?php echo $this->get_field_name('fsw_size'); ?>">
                <option value="medium" <?php selected( 'medium', $fsw_size ); ?>><?php _e('Medium', 'facebook_Subs_Widget-new'); ?></option>
                <option value="large" <?php selected( 'large', $fsw_size ); ?>><?php _e('Large', 'facebook_Subs_Widget-new'); ?></option>
            </select>
        </p>


        <p>
            <label for="<?php echo $this->get_field_id('fsw_show_screen_name'); ?>">
                <?php _e('Show Screen Name:', 'facebook_Subs_Widget-new'); ?>
            </label>
            <select id="<?php echo $this->get_field_id('fsw_show_screen_name'); ?>" name="<?php echo $this->get_field_name('fsw_show_screen_name'); ?>">
                <option value="true" <?php selected( 'true', $fsw_show_screen_name ); ?>><?php _e('Yes', 'facebook_Subs_Widget-new'); ?></option>
                <option value="false" <?php selected( 'false', $fsw_show_screen_name ); ?>><?php _e('No', 'facebook_Subs_Widget-new'); ?></option>
            </select>
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('fsw_data_dnt'); ?>">
                <?php _e('Opt-out of tailoring Facebook:', 'facebook_Subs_Widget-new'); ?>
            </label>
            <select id="<?php echo $this->get_field_id('fsw_data_dnt'); ?>" name="<?php echo $this->get_field_name('fsw_data_dnt'); ?>">
                <option value="true" <?php selected( 'true', $fsw_data_dnt ); ?>><?php _e('Yes', 'facebook_Subs_Widget-new'); ?></option>
                <option value="false" <?php selected( 'false', $fsw_data_dnt ); ?>><?php _e('No', 'facebook_Subs_Widget-new'); ?></option>
            </select>
        </p>

        <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    function update($new_instance, $old_instance) {
        // processes widget options to be saved
        $instance = $old_instance;
        $instance['fsw_title'] = sanitize_text_field($new_instance['fsw_title']);
        $instance['fsw_username'] = sanitize_text_field($new_instance['fsw_username']);
        $instance['fsw_data_show_count'] = sanitize_text_field($new_instance['fsw_data_show_count']);
        $instance['fsw_size'] = sanitize_text_field($new_instance['fsw_size']);
        $instance['fsw_show_screen_name'] = sanitize_text_field($new_instance['fsw_show_screen_name']);
        $instance['fsw_data_dnt'] = sanitize_text_field($new_instance['fsw_data_dnt']);


        return $instance;
    }

    function widget($args, $instance) {
        // outputs the content of the widget
        extract( $args );
        $fsw_title = apply_filters('widget_fsw_title', $instance['fsw_title']);
        $fsw_username = apply_filters('widget_fsw_username', $instance['fsw_username']);
        $fsw_data_show_count = apply_filters('widget_fsw_data_show_count', $instance['fsw_data_show_count']);
        $fsw_size = apply_filters('widget_fsw_size', $instance['fsw_size']);
        $fsw_show_screen_name = apply_filters('widget_fsw_show_screen_name', $instance['fsw_show_screen_name']);
        $fsw_data_dnt = apply_filters('widget_fsw_data_dnt', $instance['fsw_data_dnt']);





        ?>
        <?php echo $before_widget; ?>
        <?php if ( $fsw_title )
            echo $before_title . $fsw_title . $after_title; ?>
        <div class="container_facebook_Subs_Widget">
            <a href="http://facebook.com/<?php echo $fsw_username; ?>" class="facebook-follow-button" data-show-count="<?php echo $fsw_data_show_count; ?>" data-size="<?php echo $fsw_size; ?>" data-show-screen-name="<?php echo $fsw_show_screen_name; ?>" data-dnt="<?php echo $fsw_data_dnt; ?>" data-lang="<?php echo $fsw_language; ?>" >Follow @<?php echo $fsw_username; ?></a>
        </div>
        <?php echo $after_widget; ?>
        <?php
    }
}

function fsw_load_plugin_textdomain() {
    load_plugin_textdomain( 'facebook_Subs_Widget-new', FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'fsw_load_plugin_textdomain' );

add_action('wp_head', 'fsw_facebook_Subs_js');


function fsw_facebook_Subs_js() { 	?>
    <script>window.facebook=(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],t=window.facebook||{};if(d.getElementById(id))return;js=d.createElement(s);js.id=id;js.src="https://platform.facebook.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);t._e=[];t.ready=function(f){t._e.push(f);};return t;}(document,"script","facebook-wjs"));</script>
<?php }


