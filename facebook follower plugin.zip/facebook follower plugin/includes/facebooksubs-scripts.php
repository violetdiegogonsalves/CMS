<?php
// Add Scripts
function facebook_add_scripts(){
    // Add Main CSS
    wp_enqueue_style('facebook-main-style', plugins_url(). '/facebooksubs/css/style.css');
    // Add Main JS
    wp_enqueue_script('facebook-main-script', plugins_url(). '/facebooksubs/js/main.js');

    // Add facebook Script
    wp_register_script('facebook', 'href="https://facebook.com');
    wp_enqueue_script('facebook');
}

add_action('wp_enqueue_scripts', 'facebook_add_scripts');